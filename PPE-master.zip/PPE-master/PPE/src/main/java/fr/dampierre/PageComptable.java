package fr.dampierre;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class PageComptable {

}