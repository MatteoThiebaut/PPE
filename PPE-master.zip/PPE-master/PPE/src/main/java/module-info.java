open module fr.dampierre {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;
    exports fr.dampierre;
}